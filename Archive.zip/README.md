# Responder Chrome Extension

Outlines the web pages grid and displays the width/height in both 'em' and 'px' units when the browser is resized.

